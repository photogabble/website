<?php

	lt_include( PLOG_CLASS_PATH."class/action/admin/adminaction.class.php" );
	lt_include( PLOG_CLASS_PATH."plugins/blogtimes/class/view/pluginblogtimesconfigview.class.php" );	

	/**
	 * shows a form with the current configuration
	 */
	class PluginBlogTimesConfigAction extends AdminAction
	{
		
		function PluginBlogTimesConfigAction( $actionInfo, $request )
		{
			$this->AdminAction( $actionInfo, $request );
		}
		
		function perform()
		{
            $this->_view = new PluginBlogTimesConfigView( $this->_blogInfo );
			
			$this->setCommonData();
			
			return true;
		}
	}
?>