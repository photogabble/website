<?php
$messages["manageAppearancePlugins"] = "博客外观管理";
$messages["BlogTimes"] = "博客时间方块图设置";

$messages["blogtimes_plugin_enabled"] = "启用插件";
$messages["blogtimes_plugin"] = "博客时间方块图插件";

$messages["blogtimes_backcolor"] = "请输入您的背景颜色代码（必须是16位的RGB颜色代码）。";
$messages["blogtimes_boxcolor"] = "请输入您的方块图颜色代码（必须是16位的RGB颜色代码）。";
$messages["blogtimes_textcolor"] = "请输入您的文字颜色代码（必须是16位的RGB颜色代码）。";
$messages["blogtimes_linecolor"] = "请输入您的文章刻线颜色代码（必须是16位的RGB颜色代码）。";
$messages["blogtimes_bordercolor"] = "请输入您的外框颜色代码（必须是16位的RGB颜色代码）。";
$messages["blogtimes_tickcolor"] = "请输入您的时间刻度颜色代码（必须是16位的RGB颜色代码）。";
$messages["blogtimes_title"] = "请输入您的影象文字叙述，该文字会显示在方块图上方，请务必用英文书写。";
$messages["blogtimes_width"] = "请输入您的方块图影象长度";
$messages["blogtimes_height"] = "请输入您的方块图影象宽度";
$messages["blogtimes_lastdays"] = "请输入您所要显示的过去文章天数";

$messages["blogtimes_settings_saved_ok"] = "博客时间方块图设置储存成功。";

$messages["blogtimes_error_color_code"] = "颜色代码错误！必须是16位的RGB颜色代码，如#FFFFFF。";
$messages["blogtimes_error_title"] = "影象文字叙述错误！不可以空白。";
$messages["blogtimes_error_width"] = "方块图影象长度错误。不可小于240像素。";
$messages["blogtimes_error_height"] = "方块图影象宽度错误。不可小于30像素。";
$messages["blogtimes_error_last_days"] = "过去文章天数错误！不可小于0天。";

$messages["label_configuration"] = "设置";
$messages["label_enable"] = "启用";
$messages["label_backcolor"] = "背景颜色";
$messages["label_boxcolor"] = "方块图颜色";
$messages["label_textcolor"] = "文字颜色";
$messages["label_linecolor"] = "文章刻线颜色";
$messages["label_bordercolor"] = "外框颜色";
$messages["label_tickcolor"] = "时间刻度颜色";
$messages["label_title"] = "影象文字敘述";
$messages["label_width"] = "影象长度";
$messages["label_height"] = "影象高度";
$messages["label_lastdays"] = "过去文章天数";
?>