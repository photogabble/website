<?php
$messages["manageAppearancePlugins"] = "網誌外觀管理";
$messages["BlogTimes"] = "網誌時間方塊圖設定";

$messages["blogtimes_plugin_enabled"] = "啟動外掛程式";
$messages["blogtimes_plugin"] = "網誌時間方塊圖外掛程式";

$messages["blogtimes_backcolor"] = "請輸入你的背景顏色代碼（必須是 16 進位的 RGB 顏色代碼）。";
$messages["blogtimes_boxcolor"] = "請輸入你的方塊圖顏色代碼（必須是 16 進位的 RGB 顏色代碼）。";
$messages["blogtimes_textcolor"] = "請輸入你的文字顏色代碼（必須是 16 進位的 RGB 顏色代碼）。";
$messages["blogtimes_linecolor"] = "請輸入你的文章刻線顏色代碼（必須是 16 進位的 RGB 顏色代碼）。";
$messages["blogtimes_bordercolor"] = "請輸入你的外框顏色代碼（必須是 16 進位的 RGB 顏色代碼）。";
$messages["blogtimes_tickcolor"] = "請輸入你的時間刻度顏色代碼（必須是 16 進位的 RGB 顏色代碼）。";
$messages["blogtimes_title"] = "請輸入你的影像文字敘述，此文字會顯示在方塊圖上。必須為英文。";
$messages["blogtimes_width"] = "請輸入你的方塊圖影像長度";
$messages["blogtimes_height"] = "請輸入你的方塊圖影像寬度";
$messages["blogtimes_lastdays"] = "請輸入你所要顯示的過去文章天數。";

$messages["blogtimes_settings_saved_ok"] = "網誌時間方塊圖設定儲存成功。";

$messages["blogtimes_error_color_code"] = "顏色代碼錯誤！必須是 16 進位的 RGB 顏色代碼，如 #FFFFFF。";
$messages["blogtimes_error_title"] = "影樣文字敘述錯誤！不可為空白。";
$messages["blogtimes_error_width"] = "方塊圖影像長度錯誤。不可 < 240 像素。";
$messages["blogtimes_error_height"] = "方塊圖影像寬度錯誤。不可 < 30 像素。";
$messages["blogtimes_error_last_days"] = "過去文章天數錯誤！不可 < 0 天。";

$messages["label_configuration"] = "設定";
$messages["label_enable"] = "啟動";
$messages["label_backcolor"] = "背景顏色";
$messages["label_boxcolor"] = "方塊圖顏色";
$messages["label_textcolor"] = "文字顏色";
$messages["label_linecolor"] = "文章刻線顏色";
$messages["label_bordercolor"] = "外框顏色";
$messages["label_tickcolor"] = "時間刻度顏色";
$messages["label_title"] = "影像文字敘述";
$messages["label_width"] = "影像長度";
$messages["label_height"] = "影像高度";
$messages["label_lastdays"] = "過去文章天數";
?>