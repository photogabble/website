<?php
$messages["manageAppearancePlugins"] = "Appearance Management";
$messages["BlogTimes"] = "Blog Times";

$messages["blogtimes_plugin_enabled"] = "Enable this plugin";
$messages["blogtimes_plugin"] = "Blog Times Plugin";

$messages["blogtimes_backcolor"] = "Please input your background color (It should be RGB hex color code).";
$messages["blogtimes_boxcolor"] = "Please input your box color (It should be RGB hex color code).";
$messages["blogtimes_textcolor"] = "Please input your text color (It should be RGB hex color code).";
$messages["blogtimes_linecolor"] = "Please input your line color (It should be RGB hex color code).";
$messages["blogtimes_bordercolor"] = "Please input your border color (It should be RGB hex color code).";
$messages["blogtimes_tickcolor"] = "Please input your tick color (It should be RGB hex color code).";
$messages["blogtimes_title"] = "Please input your title. It will show on image, only accept English.";
$messages["blogtimes_width"] = "Please input your image width.";
$messages["blogtimes_height"] = "Please input your image height.";
$messages["blogtimes_lastdays"] = "Please input the last days of posts you want to show on image.";

$messages["gravatar_settings_saved_ok"] = "Blog Times settings saved successfully!";

$messages["blogtimes_error_color_code"] = "Color code error! It should be RGB hex color code. Example: #FFFFFF.";
$messages["blogtimes_error_title"] = "Title can not be empty!";
$messages["blogtimes_error_width"] = "Width can not < 240 pixels.";
$messages["blogtimes_error_height"] = "Height can not < 30 pixels.";
$messages["blogtimes_error_last_days"] = "Last days not not < 0 days.";

$messages["label_configuration"] = "Configuration";
$messages["label_enable"] = "Enable";
$messages["label_backcolor"] = "Background Color";
$messages["label_boxcolor"] = "Box Color";
$messages["label_textcolor"] = "Text Color";
$messages["label_linecolor"] = "Line Color";
$messages["label_bordercolor"] = "Border Color";
$messages["label_tickcolor"] = "Tick Color";
$messages["label_title"] = "Title";
$messages["label_width"] = "Width";
$messages["label_height"] = "Height";
$messages["label_lastdays"] = "Last Days";
?>