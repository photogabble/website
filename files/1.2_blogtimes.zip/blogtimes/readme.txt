Plugin: Blog Times
Author: Mark Wu
Idea From: Matt Mullenweg http://photomatt.net
Release Date: 2005/01/23
Version: 1.2

This plugin offers you to get the blog times image. Usage as followed:

You can use:
1. $blogtimes->isEnabled() to check the plugin is enabled or not. 
2. $blogtimes->show() to get the blog times image. 

Install:
1. Add the following code to bottom of main.template:
{if $blogtimes}
  {$blogtimes->show()}
{/if}
